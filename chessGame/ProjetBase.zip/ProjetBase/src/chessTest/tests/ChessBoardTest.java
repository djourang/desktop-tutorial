package chessTest.tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ChessBoardTest {

	
	@Test
	void test() {
		System.out.println("ChessBoardTest");
		//fail("Not yet implemented");
	}
	
	
	
	
	
	
	
	
	
	
	
	
	

}



